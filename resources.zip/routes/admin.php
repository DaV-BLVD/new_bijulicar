<?php

use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\AdminDashboardController;
use App\Http\Controllers\Admin\AdminManagementController;
use App\Http\Controllers\Admin\PermissionController;
use App\Http\Controllers\Admin\RoleController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| ADMIN ROUTES — admin guard
|--------------------------------------------------------------------------
|
| role middleware syntax: role:ROLENAME:GUARDNAME
|
| Without :admin at the end, Spatie checks the default 'web' guard.
| Since admin users live on the 'admin' guard, their roles are stored
| under guard_name='admin'. Checking the wrong guard always returns
| false and throws a 403 — even for legitimate admins and superadmins.
|
| Correct:   role:superadmin:admin        → checks admin guard
| Correct:   role:superadmin|admin:admin  → OR logic, checks admin guard
| Wrong:     role:superadmin              → checks web guard → 403
|
*/

Route::prefix('admin')
    ->name('admin.')
    ->group(function () {
        // ── Public — no login needed ──────────────────────────────────────
        Route::get('/login', [AdminAuthController::class, 'showForm'])->name('login');
        Route::post('/login', [AdminAuthController::class, 'login']);

        // ── Protected — must be logged in via admin guard ─────────────────
        Route::middleware(['auth.admin'])->group(function () {
            Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');

            // Dashboard — any logged-in admin or superadmin
            // No role: check needed — auth.admin alone is sufficient
            Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');

            // ── USER MANAGEMENT — admin + superadmin ──────────────────────
            // superadmin|admin = either role passes (pipe = OR)
            // :admin           = check against the admin guard, not web
            Route::middleware(['role:superadmin|admin:admin'])->group(function () {
                Route::get('/users', [AdminDashboardController::class, 'users'])->name('users');
                Route::patch('/users/{user}/role', [AdminDashboardController::class, 'updateUserRole'])->name('users.updateRole');
            });

            // ── PERMISSION MANAGEMENT — admin + superadmin ────────────────
            Route::resource('permissions', PermissionController::class)
                ->except(['show'])
                ->names('permissions');

            // ── ROLE MANAGEMENT — admin + superadmin ──────────────────────
            Route::resource('roles', RoleController::class)
                ->except(['show'])
                ->names('roles');

            Route::post('/roles/{role}/permissions', [RoleController::class, 'updatePermissions'])->name('roles.permissions.update');

            // ── ADMIN MANAGEMENT — superadmin ONLY ───────────────────────
            // superadmin = only this role
            // :admin     = check against the admin guard
            // A regular admin hitting these URLs gets a 403
            Route::middleware(['role:superadmin:admin'])->group(function () {
                Route::get('/admins', [AdminManagementController::class, 'index'])->name('admins.index');
                Route::get('/admins/create', [AdminManagementController::class, 'create'])->name('admins.create');
                Route::post('/admins', [AdminManagementController::class, 'store'])->name('admins.store');
                Route::get('/admins/{admin}/edit', [AdminManagementController::class, 'edit'])->name('admins.edit');
                Route::patch('/admins/{admin}', [AdminManagementController::class, 'update'])->name('admins.update');
                Route::delete('/admins/{admin}', [AdminManagementController::class, 'destroy'])->name('admins.destroy');
            });
        });
    });
