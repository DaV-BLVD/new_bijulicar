<x-guest-layout>
    <form method="POST" action="{{ route('register') }}">
        @csrf

        <!-- Name -->
        <div>
            <x-input-label for="name" :value="__('Name')" />
            <x-text-input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')" required
                autofocus autocomplete="name" />
            <x-input-error :messages="$errors->get('name')" class="mt-2" />
        </div>

        <!-- Email -->
        <div class="mt-4">
            <x-input-label for="email" :value="__('Email')" />
            <x-text-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')"
                required autocomplete="username" />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <!-- Password -->
        <div class="mt-4">
            <x-input-label for="password" :value="__('Password')" />
            <x-text-input id="password" class="block mt-1 w-full" type="password" name="password" required
                autocomplete="new-password" />
            <x-input-error :messages="$errors->get('password')" class="mt-2" />
        </div>

        <!-- Confirm Password -->
        <div class="mt-4">
            <x-input-label for="password_confirmation" :value="__('Confirm Password')" />
            <x-text-input id="password_confirmation" class="block mt-1 w-full" type="password"
                name="password_confirmation" required autocomplete="new-password" />
            <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
        </div>

        <!-- Role Selection — RBAC: this assigns the user's role at registration -->
        <div class="mt-4">
            <x-input-label :value="__('Account Type')" />
            <div class="grid grid-cols-3 gap-3 mt-2">

                <label class="cursor-pointer">
                    <input type="radio" name="role" value="buyer" class="sr-only peer"
                        {{ old('role') === 'buyer' ? 'checked' : '' }}>
                    <div
                        class="border-2 border-gray-200 rounded-lg p-3 text-center text-sm
                                peer-checked:border-indigo-500 peer-checked:bg-indigo-50 transition-all">
                        <div class="font-semibold text-gray-800">Buyer</div>
                        <div class="text-xs text-gray-500 mt-0.5">Browse & purchase</div>
                    </div>
                </label>

                <label class="cursor-pointer">
                    <input type="radio" name="role" value="seller" class="sr-only peer"
                        {{ old('role') === 'seller' ? 'checked' : '' }}>
                    <div
                        class="border-2 border-gray-200 rounded-lg p-3 text-center text-sm
                                peer-checked:border-green-500 peer-checked:bg-green-50 transition-all">
                        <div class="font-semibold text-gray-800">Seller</div>
                        <div class="text-xs text-gray-500 mt-0.5">List vehicles</div>
                    </div>
                </label>

                <label class="cursor-pointer">
                    <input type="radio" name="role" value="business" class="sr-only peer"
                        {{ old('role') === 'business' ? 'checked' : '' }}>
                    <div
                        class="border-2 border-gray-200 rounded-lg p-3 text-center text-sm
                                peer-checked:border-purple-500 peer-checked:bg-purple-50 transition-all">
                        <div class="font-semibold text-gray-800">Business</div>
                        <div class="text-xs text-gray-500 mt-0.5">Bulk & ads</div>
                    </div>
                </label>

            </div>
            <x-input-error :messages="$errors->get('role')" class="mt-2" />
        </div>

        <div class="flex items-center justify-end mt-4">
            <a class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                href="{{ route('login') }}">
                {{ __('Already registered?') }}
            </a>
            <x-primary-button class="ms-4">
                {{ __('Register') }}
            </x-primary-button>
        </div>
    </form>
</x-guest-layout>
