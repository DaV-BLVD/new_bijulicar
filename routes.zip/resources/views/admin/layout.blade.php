<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Admin') — Bijulicar</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Custom transitions for the sidebar and text */
        .sidebar-animate {
            transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .sidebar-collapsed {
            width: 4.5rem !important;
        }

        .sidebar-collapsed .hide-on-collapse {
            display: none;
        }

        .sidebar-collapsed .center-on-collapse {
            justify-content: center;
            padding-left: 0;
            padding-right: 0;
        }
    </style>
</head>

<body class="bg-gray-100 min-h-screen overflow-x-hidden">
    <div class="flex min-h-screen">
        @php $admin = auth('admin')->user(); @endphp

        <aside id="sidebar" class="sidebar-animate w-64 bg-gray-900 flex flex-col sticky top-0 h-screen z-50">

            <div class="px-5 py-5 border-b border-gray-700 flex items-center justify-between">
                <div class="hide-on-collapse">
                    <div class="text-white font-bold text-sm tracking-tight">BIJULICAR</div>
                    <div class="text-gray-500 text-[10px] font-mono leading-none">ADMIN CONSOLE</div>
                </div>
                <button onclick="toggleSidebar()"
                    class="text-gray-400 hover:text-white p-1 rounded bg-gray-800 border border-gray-700">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>
            </div>

            <div class="px-5 py-4 border-b border-gray-700 hide-on-collapse">
                <div class="text-sm text-white font-medium truncate">{{ $admin->name }}</div>
                <span
                    class="inline-block mt-1 text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider
                    {{ $admin->hasRole('superadmin') ? 'bg-red-900/50 text-red-300 border border-red-800' : 'bg-amber-900/50 text-amber-300 border border-amber-800' }}">
                    {{ $admin->getRoleNames()->first() }}
                </span>
            </div>

            <nav class="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
                <a href="{{ route('admin.dashboard') }}"
                    class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all center-on-collapse
                   {{ request()->routeIs('admin.dashboard') ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' : 'text-gray-400 hover:bg-gray-800 hover:text-white' }}">
                    <span class="font-bold w-5 text-center">D</span>
                    <span class="hide-on-collapse">Dashboard</span>
                </a>

                @can('manage users')
                    <div class="pt-4 pb-2 px-3 hide-on-collapse">
                        <p class="text-[10px] font-bold text-gray-600 uppercase tracking-[0.2em]">Management</p>
                    </div>

                    <a href="{{ route('admin.users') }}"
                        class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all center-on-collapse
                       {{ request()->routeIs('admin.users*') ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' : 'text-gray-400 hover:bg-gray-800 hover:text-white' }}">
                        <span class="font-bold w-5 text-center">U</span>
                        <span class="hide-on-collapse">Users</span>
                    </a>

                    <a href="{{ route('admin.permissions.index') }}"
                        class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all center-on-collapse
                       {{ request()->routeIs('admin.permissions*') ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' : 'text-gray-400 hover:bg-gray-800 hover:text-white' }}">
                        <span class="font-bold w-5 text-center">P</span>
                        <span class="hide-on-collapse">Permissions</span>
                    </a>

                    <a href="{{ route('admin.roles.index') }}"
                        class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all center-on-collapse
                       {{ request()->routeIs('admin.roles*') ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' : 'text-gray-400 hover:bg-gray-800 hover:text-white' }}">
                        <span class="font-bold w-5 text-center">R</span>
                        <span class="hide-on-collapse">Roles</span>
                    </a>
                @endcan

                @can('manage admins')
                    <a href="{{ route('admin.admins.index') }}"
                        class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all center-on-collapse
                       {{ request()->routeIs('admin.admins*') ? 'bg-rose-600 text-white shadow-lg shadow-rose-900/20' : 'text-gray-400 hover:bg-gray-800 hover:text-white' }}">
                        <span class="font-bold w-5 text-center text-rose-400 group-hover:text-white">A</span>
                        <span class="hide-on-collapse flex-1">Admins</span>
                        <span
                            class="hide-on-collapse text-[10px] bg-rose-900/50 text-rose-300 px-1.5 py-0.5 rounded border border-rose-800">Super</span>
                    </a>
                @endcan
            </nav>

            <div class="p-3 border-t border-gray-800">
                <form method="POST" action="{{ route('admin.logout') }}">
                    @csrf
                    <button type="submit"
                        class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-gray-500 hover:bg-red-900/20 hover:text-red-400 transition-all center-on-collapse">
                        <span class="hide-on-collapse font-medium">Log Out</span>
                    </button>
                </form>
            </div>
        </aside>

        <div class="flex-1 flex flex-col min-w-0">
            <header class="bg-white border-b border-gray-200 h-16 flex items-center px-8 sticky top-0 z-40">
                <h1 class="text-lg font-bold text-gray-800 tracking-tight">@yield('page-title', 'Dashboard')</h1>
            </header>

            <main class="p-8">
                @if (session('success'))
                    <div class="mb-6 bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 p-4 shadow-sm"
                        role="alert">
                        <p class="text-sm font-bold">Success</p>
                        <p class="text-xs">{{ session('success') }}</p>
                    </div>
                @endif

                @yield('content')
            </main>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('sidebar-collapsed');

            // Persist the user's preference
            const isCollapsed = sidebar.classList.contains('sidebar-collapsed');
            localStorage.setItem('admin_sidebar_collapsed', isCollapsed);
        }

        // Initialize state from local storage
        document.addEventListener('DOMContentLoaded', () => {
            if (localStorage.getItem('admin_sidebar_collapsed') === 'true') {
                document.getElementById('sidebar').classList.add('sidebar-collapsed');
            }
        });
    </script>
</body>

</html>
