<?php

namespace App\Providers;
use App\Models\Admin;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Gate::before(function ($user, $ability) {
    // This $user is the one passed from @can('perm', $user)
    if ($user instanceof Admin && $user->hasRole('superadmin')) {
        return true;
    }
});
    }
}
